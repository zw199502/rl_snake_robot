configuration of the control mode for joint ----- position PID control
