load joint controllers from snake_control.yaml
