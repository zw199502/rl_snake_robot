1. config: control mode for joints ---- PID position control
2. launch: load joint controllers from snake_control.yaml
